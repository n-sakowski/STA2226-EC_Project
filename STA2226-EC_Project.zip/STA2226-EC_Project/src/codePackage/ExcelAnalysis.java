package codePackage;

import java.io.*;
import java.util.*;

public class ExcelAnalysis {

    public static void main(String[] args) throws Exception {
        List<String[]> data = readCSV("resources/servants.csv");

        List<Double> maxAttackList = new ArrayList<>();
        Map<String, List<Double>> genderGroups = new HashMap<>();
        List<Double> ids = new ArrayList<>();
        List<Double> stars = new ArrayList<>();
        
        for (String[] row : data) {
            if (row.length >= 4) {
                try {
                    double maxAttack = Double.parseDouble(row[2]);  
                    String gender = row[1];  
                    double id = Double.parseDouble(row[0]); 
                    double starRating = Double.parseDouble(row[3]);  

                    maxAttackList.add(maxAttack);

                    genderGroups.computeIfAbsent(gender, k -> new ArrayList<>()).add(maxAttack);

                    ids.add(id);
                    stars.add(starRating);
                } catch (NumberFormatException e) {
                    System.err.println("Skipping invalid row (unable to parse numbers): " + Arrays.toString(row));
                }
            } else {
                System.err.println("Skipping incomplete row: " + Arrays.toString(row));
            }
        }

        calculateStats(maxAttackList);
        
        System.out.println("------------------------------");

        calculateMeanByGender(genderGroups);

        System.out.println("------------------------------");
        
        chiSquareTest(genderGroups, stars);

        System.out.println("------------------------------");

        linearRegression(ids, stars);
    }

    private static List<String[]> readCSV(String filename) throws IOException {
        List<String[]> data = new ArrayList<>();
        BufferedReader br = new BufferedReader(new FileReader(filename));
        String line;

        br.readLine();  

        while ((line = br.readLine()) != null) {
            data.add(line.split(","));
        }
        br.close();
        return data;
    }

    private static void calculateStats(List<Double> data) {
        Collections.sort(data);
        double mean = data.stream().mapToDouble(d -> d).average().orElse(0.0);
        double median = (data.size() % 2 == 0) ? 
            (data.get(data.size() / 2 - 1) + data.get(data.size() / 2)) / 2 : 
            data.get(data.size() / 2);

        Map<Double, Integer> frequencyMap = new HashMap<>();
        for (double num : data) {
            frequencyMap.put(num, frequencyMap.getOrDefault(num, 0) + 1);
        }

        int maxCount = Collections.max(frequencyMap.values());
        List<Double> mode = new ArrayList<>();
        for (Map.Entry<Double, Integer> entry : frequencyMap.entrySet()) {
            if (entry.getValue() == maxCount) {
                mode.add(entry.getKey());
            }
        }

        double variance = data.stream().mapToDouble(d -> Math.pow(d - mean, 2)).average().orElse(0.0);
        double standardDeviation = Math.sqrt(variance);

        System.out.println("Mean: " + String.format("%.4f", mean));
        System.out.println("Median: " + String.format("%.4f", median));
        System.out.println("Mode: " + mode);
        System.out.println("Standard Deviation: " + String.format("%.4f", standardDeviation));
    }

    private static void calculateMeanByGender(Map<String, List<Double>> genderGroups) {
        for (Map.Entry<String, List<Double>> entry : genderGroups.entrySet()) {
            String gender = entry.getKey();
            List<Double> attacks = entry.getValue();
            double mean = attacks.stream().mapToDouble(d -> d).average().orElse(0.0);
            // Round and print the mean for each gender
            System.out.println("Mean max_attack for " + gender + ": " + String.format("%.4f", mean));
        }
    }

    private static void chiSquareTest(Map<String, List<Double>> genderGroups, List<Double> stars) {
        int[] maleStarCount = new int[5];   
        int[] femaleStarCount = new int[5]; 

        for (int i = 0; i < stars.size(); i++) {
            String gender = (i % 2 == 0) ? "male" : "female" ;  
            int star = (int) stars.get(i).doubleValue();

            if ("male".equals(gender)) {
                maleStarCount[star - 1]++;
            } else {
                femaleStarCount[star - 1]++;
            }
        }

        System.out.println("Chi-Square Test (Male Star Count): " + Arrays.toString(maleStarCount));
        System.out.println("Chi-Square Test (Female Star Count): " + Arrays.toString(femaleStarCount));
        
        System.out.println("58/" + (5+7+25+59+58) + " 5* males. 55/" + (6+9+21+63+55) + " 5* females.");
        System.out.println("There are more 5* males than 5* females, both in total and proportionally.");

    }

    private static void linearRegression(List<Double> ids, List<Double> stars) {
        double sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
        int n = ids.size();

        for (int i = 0; i < n; i++) {
            double x = ids.get(i);
            double y = stars.get(i);
            sumX += x;
            sumY += y;
            sumXY += x * y;
            sumX2 += x * x;
        }

        double slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
        double intercept = (sumY - slope * sumX) / n;

        System.out.println("Linear Regression: y = " + String.format("%.4f", slope) + "x + " + String.format("%.4f", intercept));
    }
}
